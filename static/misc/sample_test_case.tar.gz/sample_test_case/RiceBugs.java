/*
 * The MIT License
 *
 * Copyright 2016 Gary Munnelly.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

import java.util.Scanner;

/**
 * Gets input, runs the Rice Bugs simulation and displays results
 * 
 * @author Gary Munnelly
 */
public class RiceBugs {
    /**
     * Bugs in our simulation
     */
    private static Bug[] bugs;
    /**
     * The field on which we're simulating 
     */
    private static Plant[][] plants;
    
    private static int field_width, field_height;
    private static int num_bugs;
    private static int num_cycles;
    
    /**
     * Read inputs from System.in and use these to initialize the program.
     */
    public static void fetchInputs() {
        // Listen on System.in
        Scanner input = new Scanner(System.in);
        
        // Initialize the field
        field_width  = input.nextInt();
        field_height = input.nextInt();        
        plants = new Plant[field_height][field_width];
        for (Plant[] plant : plants) {
            for (int j = 0; j<plant.length; j++) {
                plant[j] = new Plant();
            }
        }
              
        // Get the time for which the simulation will run
        num_cycles = input.nextInt();
        
        // Initialize the bugs
        num_bugs   = input.nextInt();        
        bugs = new Bug[num_bugs];        
        for(int i=0; i<bugs.length; i++) {
            int x = input.nextInt();
            int y = input.nextInt();
            int start_time = input.nextInt();
            char direction = input.next().charAt(0);
            
            // Put the bug in the field
            bugs[i] = new Bug(x, y, start_time, direction);
        }
    }
    
    /**
     * Simulate the rice bugs game.
     */
    public static void simulateRiceBugs() {
        
        for(int time=0; time <num_cycles; time++) {             
            
            // Activate any bugs that need to wake up
            for(Bug bug : bugs) {                
                bug.activate(time);
            }
            
            // Infect our current position
            for(Bug bug : bugs) {                
                bug.infect(plants);
            }
            
            // Move and consume
            for(Bug bug : bugs) {                                
                bug.move(plants); 
                // Consuming now won't affect combat as all bugs grow at the 
                // same rate
                bug.consume(plants);
            }
                        
            // Fight 
            for(int i=0; i<bugs.length-1; i++) {
                for(int j=i+1; j<bugs.length; j++) {
                    if(bugs[i].intersects(bugs[j])) {                         
                        bugs[i].fight(bugs[j]);
                    }
                }
            }
        }
    }
    
    /**
     * Print the final state of the Rice Bugs game.
     */
    public static void displayResult() {
        int live_plants = 0;
        int live_bugs = 0;
        
        // Count living plants s
        for(Plant[] plant : plants) {
            for(Plant p : plant) {
                if(!p.isInfected()) {
                    live_plants++;
                }
            }
        }
        
        // Count living bugs 
        for(Bug bug : bugs) {
            if(bug.isAlive()) {
                live_bugs++;
            }
        }
        
        // Print answer 
        System.out.printf("%d %d\n", live_plants, live_bugs);
    }
    
    /**
     * Run the simulation
     * 
     * @param args 
     */
    public static void main( String [] args ) {
        fetchInputs();      // Get user input
        simulateRiceBugs(); // Run the game       
        displayResult();    // Show the result
    }
}
