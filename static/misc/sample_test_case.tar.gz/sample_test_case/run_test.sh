#!/bin/bash

if [ -f output.txt ] ; then
		rm output.txt
fi

for i in ${@:2}; do
		printf "%s\n" "$(java $1 < $i)" >> output.txt
done

#echo "$output" > output.txt

