/*
 * The MIT License
 *
 * Copyright 2016 Gary Munnelly.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

/**
 * Represents the state of a single bug in the RiceBugs game
 * 
 * @author Gary Munnelly
 */
public class Bug {
    /**
     * The activation time for this bug in the simulation
     */
    private int start_time;
    
    /**
     * The bug's strength as determined by how many plants it has consumed
     */
    private int strength;
    
    /**
     * The coordinates of the bug in the field
     */
    private int x, y;
    
    /**
     * Amount by which a bug moves each turn in each direction.
     */
    private int delta_x, delta_y;
    
    /**
     * True if bug is alive. False otherwise
     */
    private boolean alive;
    
    /**
     * Whether or not this bug's activation time has been reached.
     */
    private boolean activated;
    
    /**
     * Used for translating direction code to delta_x, delta_y values.
     */
    private static final char ROOT_DIRECTION = 'A';
    
    /**
     * Create a new, default bug instance.
     */
    public Bug() {
        this.start_time = 0;
        this.strength   = 0;        
        this.delta_x    = 0;
        this.delta_y    = 0;        
        this.x = this.y = 0;
        
        this.activated = true;
        this.alive = true;
    }
    
    /**
     * Initialize a new bug to the values given
     * 
     * @param x The bug's starting x position
     * @param y The bug's starting y position
     * @param start_time The bug's activation time
     * @param direction The direction in which the bug moves each turn
     */
    public Bug(int x, int y, int start_time, char direction) {
        this.start_time = start_time;        
        this.x = x;
        this.y = y;
        this.strength = 0;                                
        this.alive = true;
        this.activated = (this.start_time == 0);
        
        // Convert direction code to delta_x and delta_y values. 'Cos long 
        // switch statements are the pits
        int k = (int)(direction - Bug.ROOT_DIRECTION);
        k += (k>3)? 1 : 0;
        this.delta_x = k%3 - 1;
        this.delta_y = k/3 - 1;
    }
    
    /**
     * Check if this bug should be activated, given the current time.
     * 
     * @param time The current time in the game simulation
     */
    public void activate( int time ) {        
        if(time >= this.start_time) { 
            // https://www.youtube.com/watch?v=gH1JMdWpJ54
            this.activated = true;
        }
    }
    
    /**
     * Check if this bug is still alive 
     * 
     * @return True if bug is alive. False otherwise
     */
    public boolean isAlive() {
        // Insert Frankenstein reference here
        return this.alive;
    }
    
    /**
     * Test if this bug has been activated yet
     * 
     * @return True if bug has been activated. False otherwise
     */
    public boolean isActive() {
        return this.activated;
    }
    
    /**
     * Moves a bug across the field and kills it if it has moved outside the 
     * bounds defined by the plants array
     * 
     * @param plants 2D array representing field in which simulation takes place
     */
    public void move(Plant plants[][]) {
        // Move bug if it is alive and has been activated */
        if( this.isAlive()  && this.isActive() ) {
            /* Move by delta values */
            this.x += this.delta_x;
            this.y += this.delta_y;
            
            /* If we're outside permissable bounds, then die */
            if(!this.isWithinArea(0,0,plants[0].length,plants.length)) {
                this.die();
            }
        }        
    }
    
    /**
     * Eat a plant and gain strength equivalent to its nutritional value.
     * 
     * @param plants The field of plants on which the game is played
     */
    public void consume(Plant[][] plants) {
        // Make sure we can eat
        if( this.isAlive() && this.isActive()) {                             
            // Nom nom nom
            this.strength += plants[this.y][this.x].getNutrition();            
        }
    }
    
    /**
     * Bug should infect the plant it's standing on 
     * 
     * @param plants The field of plants on which the game is played
     */
    public void infect(Plant[][] plants) {
        if( this.isAlive() && this.isActive()) {
            // What a waste
            plants[this.y][this.x].infect();
        }
    }
    
    /*
     *                         ueeeeeu..
     *                 ur d$$$$$$$$$$$$$$Nu
     *               d$$$ "$$$$$$$$$$$$$$$$$$e.
     *           u$$c   ""   ^"^**$$$$$$$$$$$$$b.
     *         z$$#"""           `!?$$$$$$$$$$$$$N.
     *       .$P                   ~!R$$$$$$$$$$$$$b
     *      x$F                 **$b. '"R).$$$$$$$$$$
     *     J^"                           #$$$$$$$$$$$$.
     *    z$e                      ..      "**$$$$$$$$$
     *   :$P           .        .$$$$$b.    ..  "  #$$$$
     *   $$            L          ^*$$$$b   "      4$$$$L
     *  4$$            ^u    .e$$$$e."*$$$N.       @$$$$$
     *  $$E            d$$$$$$$$$$$$$$L "$$$$$  mu $$$$$$F
     *  $$&            $$$$$$$$$$$$$$$$N   "#* * ?$$$$$$$N
     *  $$F            '$$$$$$$$$$$$$$$$$bec...z$ $$$$$$$$
     * '$$F             `$$$$$$$$$$$$$$$$$$$$$$$$ '$$$$E"$
     *  $$                  ^""""""`       ^"*$$$& 9$$$$N
     *  k  u$                                  "$$. "$$P r
     *  4$$$$L                                   "$. eeeR
     *   $$$$$k                                   '$e. .@
     *   3$$$$$b                                   '$$$$
     *    $$$$$$                                    3$$"
     *     $$$$$  dc                                4$F
     *      RF** <$$                                J"
     *       #bue$$$LJ$$$Nc.                        "
     *        ^$$$$$$$$$$$$$r
     *          `"*$$$$$$$$$
     *
     *
     *      MM   MM  OOOOO  RRRRRR  TTTTTTT  AAAAA  LLL
     *      MMM MMM OOO OOO RR   RR TTTTTTT AAA AAA LLL
     *      MMMMMMM OO   OO RR   RR   TTT   AA   AA LLL
     *      MM M MM OO   OO RRRRRRR   TTT   AAAAAAA LLL
     *      MM   MM OO   OO RR RRRR   TTT   AAAAAAA LLL
     *      MM   MM OOO OOO RR  RRR   TTT   AA   AA LLLLLLL
     *      MM   MM  OOOOO  RR   RR   TTT   AA   AA LLLLLLL
     * 
     *      KK   KK  OOOOO  MM   MM BBBBBB   AAAAA  TTTTTTT
     *      KK  KKK OOO OOO MMM MMM BB  BBB AAA AAA TTTTTTT
     *      KK KKK  OO   OO MMMMMMM BB  BBB AA   AA   TTT  
     *      KKKKK   OO   OO MM M MM BBBBBB  AAAAAAA   TTT  
     *      KK kKK  OO   OO MM   MM BB  BBB AAAAAAA   TTT  
     *      KK  KKK OOO OOO MM   MM BB  BBB AA   AA   TTT  
     *      KK   KK  OOOOO  MM   MM BBBBBB  AA   AA   TTT  
     */
    
    /**
     * Resolve combat between two bugs based on their relative strength
     * 
     * @param enemy The opponent that this bug is fighting
     */
    public void fight(Bug enemy) {
        
        if(this.isAlive() && enemy.isAlive()  && this.isActive() && enemy.isActive()) {        
            // Resolve combat based on relative bug strength
            if(enemy.strength > this.strength) { // Enemy stronger than me
                // It's just a flesh wound
                this.die();
            } else if(this.strength > enemy.strength) { // Me stronger than enemy
                // Finish him
                enemy.die();
            }
        }        
    }
    
    /**
     * Check this bug has encountered the argument bug (is on the 
     * same square).
     * 
     * @param bug The bug who we're testing against
     * @return True if we're on the same square as bug. False 
     * otherwise
     */
    public boolean intersects( Bug bug ) {
        return (this.x == bug.x && this.y == bug.y);
    }
        
    /**
     * Check if bug is standing within the given bounds
     * 
     * @param x lower x bound
     * @param y lower y bound
     * @param w width of area
     * @param h height of area
     * 
     * @return True if bug is standing within the region. False otherwise
     */
    public boolean isWithinArea(int x, int y, int w, int h) {
        // Insert "Yo Mamma" joke
        return (this.x >= x && this.y >= y && this.x < w && this.y < h);
    }
    
    /**
     * Kill this bug.
     */
    public void die() {
        // The ending to Terminator 2 is so much less emotional when you 
        // realize this is basically all that the T-800 experienced
        this.alive = false;
    }
}
 
